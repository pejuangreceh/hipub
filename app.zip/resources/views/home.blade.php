@extends('layout')

@section('container')
<div class="h-screen w-full">
    {{-- {{dd($artikel)}} --}}
    
</div>
@endsection
