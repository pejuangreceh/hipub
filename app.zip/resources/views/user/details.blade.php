@extends('layout')
@section('container')
<div class="h-screen w-full pt-[100px] px-[92px]">

    <div class="flex flex-col space-y-8">
        <div class="w-full py-2 pl-14 pr-4 flex justify-between rounded-[20px] bg-white">
            <div class="flex space-x-4">
                <div class=" w-10 h-10 my-auto rounded-full bg-pink-400"></div>
                <div class=" flex flex-col">
                    <h1 class="font-bold capitalize">{{Auth::user()->name}} </h1>
                    <h2 class=" text-sm">{{Auth::user()->email}}</h2>
                    {{-- {{$coba_data}} --}}
                </div>
            </div>
            <div>
                <i class='bx bx-message-square-dots bx-md mt-1'></i>
            </div>
        </div>
        <div class="bg-white px-[77px] py-[30px] text-center rounded-[20px]">
            <h2 class=" text-3xl capitalize">judul artikel</h2>
            <h1 class=" mt-8 font-bold text-3xl capitalize">{{$article->judul_artikel}}</h1>
            <div class="mt-10 flex flex-warp justify-center space-x-6">
                {{-- @if(file_exists(public_path("revisi_files/{$article->file_revisi}"))) --}}
                @if($article->file_revisi != NULL)
                <div class="flex">
                    <a href="{{asset('revisi_files/'.$article->file_revisi)}}" target="_blank"><button type="button" class="font-bold text-white w-[200px] text-center bg-oranges hover:bg-orange-700 py-2 rounded-lg capitalize">Download Revisi Artikel</button></a>
                </div>
                @endif
                @if($article->loa_file != NULL)
                <div class="flex">
                    <a href="{{asset('loa_files/'.$article->loa_file)}}" target="_blank"><button type="button" class="font-bold text-white w-[200px] text-center bg-greens hover:bg-green-700 py-2 rounded-lg capitalize">Download LOA</button></a>
                </div>
                @endif
                <div class="flex">
                    <a href="{{asset('article_files/'.$article->nama_file)}}" target="_blank"><button type="button" class="font-bold text-white w-[200px] text-center bg-reds hover:bg-red-700 py-2 rounded-lg capitalize">Download Artikel</button></a>
                </div>
                {{-- <a href="{{url('').'/'.Auth::user()->type.'/'.$article->id.'revisi'}}"> --}}
                    <?php echo ($article->status == 'Revisi (E)')?'<a href="revisi">':((($article->status == 'Proses')||($article->status == 'Verifikasi (E)'))?'<a href="revisi_vendor">':'');?>
                <div class="capitalize font-bold text-white bg-blue-500 px-20 py-2 rounded-[10px]">{{($article->status == 'Verifikasi (E)')?'Proofreading':$article->status}}</div>
                </a>
            </div>
        </div>
        <div class="bg-white px-14 py-11 h-96 rounded-[20px]  overflow-auto scrollbar-hide">
            <h1 class="text-3xl capitalize">komentar :</h1>
            <p class=" text-[22px]">
                {{($article->komentar_vendor == "Belum ada komentar") ? $article->komentar_editor : $article->komentar_vendor}}
            </p>
        </div>
    </div>
</div>
@endsection