@extends('layout')
@section('container')
    <div class="h-screen w-full pt-[141px] px-96">
        @if($errors->any())
            <div class="alert alert-danger">
                {{ $errors->first('message') }}
            </div>
        @endif
        <form action="{{url('')}}/{{Auth::user()->type}}/{{$article->id}}/{{$link_form}}" method="POST" enctype="multipart/form-data">
            @method('put')
            @csrf
            <input type="hidden" name="id_user" id="id_user" value="{{Auth::user()->id}}">
            <input type="hidden" name="status" id="status" value="{{$status_value}}">
            <div class="flex flex-col space-y-5">
                <input class="w-full p-5 pl-5 rounded-2xl" type="text" name="judul_artikel" placeholder="Judul Artikel" value="{{$article->judul_artikel}}">
                <select class="capitalize appearance-none p-5 pl-5 rounded-2xl" name="kategori_artikel" id="" required>
                    <option disabled selected class="capitalize ">pilih kategori</option>
                    <option {{($article->kategori_artikel == 'teknologi')?'selected':'';}} class="capitalize " value="teknologi">teknologi</option>
                    <option {{($article->kategori_artikel == 'kesehatan')?'selected':'';}} class="capitalize " value="kesehatan">kesehatan</option>
                    <option {{($article->kategori_artikel == 'ekonomi')?'selected':'';}} class="capitalize " value="ekonomi">ekonomi</option>
                    <option {{($article->kategori_artikel == 'umum')?'selected':'';}} class="capitalize " value="umum">umum</option>
                </select>
                {{-- <div class="flex">
                        Input File sementara 
                    <input type="file" name="nama_file" id="nama_file" required>
                </div> --}}
                <div class="flex">
                    <div class="w-3/4 rounded-l-2xl bg-white p-5" id="fileName">
                        {{$article->nama_file}}
                    </div>
                    <label class="w-1/4 p-5 capitalize rounded-r-2xl bg-gray-400 cursor-pointer" for="file">
                        browse
                    </label>
                    <input class="hidden" id="file" clas name="nama_file" type="file"  onchange="ganti()">
                </div>
                <button class="capitalize py-5 px-12 w-1/3 bg-black rounded-xl text-white font-bold text-3xl hover:bg-orange-700 hover:text-black" type="submit">Revisi artikel</button>
            </div>    
        </form>
    </div>
    <script>
        function ganti(){
            var file_output =  document.getElementById('fileName');
            var file_name = document.getElementById('file');
            file_output.innerHTML = file_name.value;
        }
        setTimeout(function() {
            $('.alert').fadeOut('fast');
        }, 5000);
    </script>
    
@endsection