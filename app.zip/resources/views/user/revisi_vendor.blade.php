@extends('layout')
@section('container')
    <div class="h-screen w-full pt-[141px] px-96">
        @if($errors->any())
            <div class="alert alert-danger">
                {{ $errors->first('message') }}
            </div>
        @endif
        <form action="{{url('')}}/{{Auth::user()->type}}/{{$article->id}}/{{$link_form}}" method="POST" enctype="multipart/form-data">
            @method('put')
            @csrf
            {{-- <input type="hidden" name="id_user" id="id_user" value="{{Auth::user()->id}}"> --}}
            <input type="hidden" name="status" id="status" value="{{$status_value}}">
            <div class="flex flex-col space-y-5">
                <input readonly class="w-full p-5 pl-5 rounded-2xl" type="text" name="judul_artikel" placeholder="Judul Artikel" value="{{$article->judul_artikel}}">
                <input readonly class="capitalize w-full p-5 pl-5 rounded-2xl" type="text" name="kategori_artikel" placeholder="Judul Artikel" value="{{$article->kategori_artikel}}">
                <select class="capitalize appearance-none p-5 pl-5 rounded-2xl" name="vendor" id="" required>
                    <option disabled selected class="capitalize ">pilih vendor</option>
                    @foreach ($vendors as $v)
                    <option {{($article->vendor == $v->bidang)?'selected':''}} class="capitalize" value="{{$v->bidang}}">{{$v->name}}</option>
                    @endforeach
                </select>
                <select class="capitalize appearance-none p-5 pl-5 rounded-2xl" name="jurnal" id="" required>
                    <option disabled class="capitalize ">pilih jurnal </option>
                    <option {{($article->jurnal == 'scopus')?'selected':''}} class="capitalize" value="scopus">scopus</option>
                    <option {{($article->jurnal == 'sinta2')?'selected':''}} class="capitalize" value="sinta2">sinta2</option>
                    <option {{($article->jurnal == 'sinta3')?'selected':''}} class="capitalize" value="sinta3">sinta3</option>
                    <option {{($article->jurnal == 'sinta4')?'selected':''}} class="capitalize" value="sinta4">sinta4</option>
                    <option {{($article->jurnal == 'sinta5')?'selected':''}} class="capitalize" value="sinta5">sinta5</option>
                    <option {{($article->jurnal == 'sinta6')?'selected':''}} class="capitalize" value="sinta6">sinta6</option>
                </select>
                {{-- <div class="flex">
                        Input File sementara 
                    <input type="file" name="nama_file" id="nama_file" required>
                </div> --}}
                <div class="flex">
                    <div class="w-3/4 rounded-l-2xl bg-white p-5" id="coverName">
                        {{($article->cover_file == NULL)?'Upload Cover Letter':$article->cover_file}}
                    </div>
                    <label class="w-1/4 p-5 capitalize rounded-r-2xl bg-gray-400 cursor-pointer" for="cover_file">
                        browse
                    </label>
                    <input class="hidden" id="cover_file" name="cover_file" type="file"  onchange="ganti()">
                </div>
                <div class="flex">
                    <div class="w-3/4 rounded-l-2xl bg-white p-5" id="cvName">
                        {{($article->cv_file == NULL)?'Upload CV':$article->cv_file}}
                    </div>
                    <label class="w-1/4 p-5 capitalize rounded-r-2xl bg-gray-400 cursor-pointer" for="cv_file">
                        browse
                    </label>
                    <input class="hidden" id="cv_file" name="cv_file" type="file"  onchange="ganti2()">
                </div>
                <button class="capitalize py-5 px-12 w-1/3 bg-black rounded-xl text-white font-bold text-3xl hover:bg-orange-700 hover:text-black" type="submit">Update Data Vendor</button>
            </div>    
        </form>
    </div>
    <script>
        function ganti(){
            var file_output =  document.getElementById('coverName');
            var file_name = document.getElementById('cover_file');
            file_output.innerHTML = file_name.value;
        }
        function ganti2(){
            var file_output2 =  document.getElementById('cvName');
            var file_name2 = document.getElementById('cv_file');
            file_output2.innerHTML = file_name2.value;
        }
        setTimeout(function() {
            $('.alert').fadeOut('fast');
        }, 5000);
    </script>
    
@endsection