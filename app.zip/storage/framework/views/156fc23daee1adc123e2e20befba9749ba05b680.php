
<?php $__env->startSection('container'); ?>

<div class="h-screen w-full">
    <form action="/update_article/<?php echo e($article->id); ?>" method="POST">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id_user" id="id_user" value="1">
        <input type="hidden" name="status" id="status" value="dalam_proses">

        <table>
            <tr>
                <td>Judul Artikel</td>
                <td><input type="text" name="judul_artikel" id="judul_artikel" value="<?php echo e($article->judul_artikel); ?>" required></td>
            </tr>
            <tr>
                <td>Kategori Artikel</td>
                <td><input type="text" name="kategori_artikel" id="kategori_artikel" value="<?php echo e($article->kategori_artikel); ?>" required></td>
            </tr>
            <tr>
                <td>Nama File</td>
                <td><input type="text" name="nama_file" id="nama_file" value="<?php echo e($article->nama_file); ?>" required></td>
            </tr>
        </table>
        <input name="submit" type="submit" value="submit">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipub_local\resources\views/article/edit_article.blade.php ENDPATH**/ ?>