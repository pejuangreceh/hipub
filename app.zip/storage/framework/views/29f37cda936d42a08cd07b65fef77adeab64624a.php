
<?php $__env->startSection('container'); ?>

    <div class="h-screen w-full">
        
        <div>
            <a href="/add_article">
                Link Tambah Artikel
            </a>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipub_local\resources\views/article/index_article.blade.php ENDPATH**/ ?>