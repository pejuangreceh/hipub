
<?php $__env->startSection('container'); ?>
    <div class="h-screen w-full px-16 py-16">
        <div class="bg-white rounded-[20px] px-5">

            <table class="w-full" id="search">
                <thead>
                    <tr class=" py-9">
                        <th class="capitalize w-1/12 font-bold px-3 py-5"> no</td>
                        <th class="capitalize w-6/12 font-bold"> judul artikel</td>
                            <th class="capitalize w-2/12 font-bold"> Author</td>
                        <th class="capitalize w-3/12 font-bold"> status</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="w-1/12 text-center border-b border-[#727272] border-opacity-50 py-3"><?php echo e($loop->iteration); ?></td>
                        <td class="w-6/12 capitalize border-b border-[#727272] border-opacity-50"><?php echo e($a->judul_artikel); ?></td>
                        <td class="w-2/12 capitalize border-b border-[#727272] border-opacity-50"><?php echo e($a->name); ?></td>
                        <td class="w-3/12 border-b text-white capitalize border-[#727272] border-opacity-50 text-center">
                            <a href="<?php echo e(url('')); ?>/<?php echo e(Auth::user()->type); ?>/<?php echo e($a->id); ?>/artikel"><span class="bg-blue-600 px-10 rounded-2xl font-bold py-1"><?php echo e($a->status); ?></span></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipub_local\resources\views/vendor/artikel.blade.php ENDPATH**/ ?>