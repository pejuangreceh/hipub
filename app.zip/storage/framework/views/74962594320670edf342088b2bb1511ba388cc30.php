
<?php $__env->startSection('container'); ?>
    <div class="h-screen w-full pt-[141px] px-96">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('message')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(url('')); ?>/<?php echo e(Auth::user()->type); ?>/<?php echo e($article->id); ?>/<?php echo e($link_form); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            
            <input type="hidden" name="status" id="status" value="<?php echo e($status_value); ?>">
            <div class="flex flex-col space-y-5">
                <input readonly class="w-full p-5 pl-5 rounded-2xl" type="text" name="judul_artikel" placeholder="Judul Artikel" value="<?php echo e($article->judul_artikel); ?>">
                <input readonly class="capitalize w-full p-5 pl-5 rounded-2xl" type="text" name="kategori_artikel" placeholder="Judul Artikel" value="<?php echo e($article->kategori_artikel); ?>">
                <select class="capitalize appearance-none p-5 pl-5 rounded-2xl" name="vendor" id="" required>
                    <option disabled selected class="capitalize ">pilih vendor</option>
                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(($article->vendor == $v->bidang)?'selected':''); ?> class="capitalize" value="<?php echo e($v->bidang); ?>"><?php echo e($v->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select class="capitalize appearance-none p-5 pl-5 rounded-2xl" name="jurnal" id="" required>
                    <option disabled class="capitalize ">pilih jurnal </option>
                    <option <?php echo e(($article->jurnal == 'scopus')?'selected':''); ?> class="capitalize" value="scopus">scopus</option>
                    <option <?php echo e(($article->jurnal == 'sinta2')?'selected':''); ?> class="capitalize" value="sinta2">sinta2</option>
                    <option <?php echo e(($article->jurnal == 'sinta3')?'selected':''); ?> class="capitalize" value="sinta3">sinta3</option>
                    <option <?php echo e(($article->jurnal == 'sinta4')?'selected':''); ?> class="capitalize" value="sinta4">sinta4</option>
                    <option <?php echo e(($article->jurnal == 'sinta5')?'selected':''); ?> class="capitalize" value="sinta5">sinta5</option>
                    <option <?php echo e(($article->jurnal == 'sinta6')?'selected':''); ?> class="capitalize" value="sinta6">sinta6</option>
                </select>
                
                <div class="flex">
                    <div class="w-3/4 rounded-l-2xl bg-white p-5" id="coverName">
                        <?php echo e(($article->cover_file == NULL)?'Upload Cover Letter':$article->cover_file); ?>

                    </div>
                    <label class="w-1/4 p-5 capitalize rounded-r-2xl bg-gray-400 cursor-pointer" for="cover_file">
                        browse
                    </label>
                    <input class="hidden" id="cover_file" name="cover_file" type="file"  onchange="ganti()">
                </div>
                <div class="flex">
                    <div class="w-3/4 rounded-l-2xl bg-white p-5" id="cvName">
                        <?php echo e(($article->cv_file == NULL)?'Upload CV':$article->cv_file); ?>

                    </div>
                    <label class="w-1/4 p-5 capitalize rounded-r-2xl bg-gray-400 cursor-pointer" for="cv_file">
                        browse
                    </label>
                    <input class="hidden" id="cv_file" name="cv_file" type="file"  onchange="ganti2()">
                </div>
                <button class="capitalize py-5 px-12 w-1/3 bg-black rounded-xl text-white font-bold text-3xl hover:bg-orange-700 hover:text-black" type="submit">Update Data Vendor</button>
            </div>    
        </form>
    </div>
    <script>
        function ganti(){
            var file_output =  document.getElementById('coverName');
            var file_name = document.getElementById('cover_file');
            file_output.innerHTML = file_name.value;
        }
        function ganti2(){
            var file_output2 =  document.getElementById('cvName');
            var file_name2 = document.getElementById('cv_file');
            file_output2.innerHTML = file_name2.value;
        }
        setTimeout(function() {
            $('.alert').fadeOut('fast');
        }, 5000);
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipub_local\resources\views/user/revisi_vendor.blade.php ENDPATH**/ ?>