
<?php $__env->startSection('container'); ?>

<div class="h-screen w-full">

        <input type="hidden" name="id_user" id="id_user" value="1">
        <input type="hidden" name="status" id="status" value="dalam_proses">

        <table>
            <tr>
                <td>Judul Artikel : </td>
                <td><?php echo e($article->judul_artikel); ?></td>
            </tr>
            <tr>
                <td>Kategori Artikel : </td>
                <td><?php echo e($article->kategori_artikel); ?></td>
            </tr>
            <tr>
                <td>Nama File : </td>
                <td><?php echo e($article->nama_file); ?></td>
            </tr>
            <tr>
                <td>Link File</td>
                <td><a href="<?php echo e(public_path($article->nama_file)); ?>">Klik  disini</a></td>
            </tr>
        </table>
        <a href="javascript:history.back()">Back</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipub\resources\views/article/show_article.blade.php ENDPATH**/ ?>