
<?php $__env->startSection('container'); ?>
<div class="h-screen w-full pt-[100px] px-[92px]">

    <div class="flex flex-col space-y-8">
        <div class="w-full py-2 pl-14 pr-4 flex justify-between rounded-[20px] bg-white">
            <div class="flex space-x-4">
                <div class=" w-10 h-10 my-auto rounded-full bg-pink-400"></div>
                <div class=" flex flex-col">
                    <h1 class="font-bold capitalize"><?php echo e(Auth::user()->name); ?> </h1>
                    <h2 class=" text-sm"><?php echo e(Auth::user()->email); ?></h2>
                    
                </div>
            </div>
            <div>
                <i class='bx bx-message-square-dots bx-md mt-1'></i>
            </div>
        </div>
        <div class="bg-white px-[77px] py-[30px] text-center rounded-[20px]">
            <h2 class=" text-3xl capitalize">judul artikel</h2>
            <h1 class=" mt-8 font-bold text-3xl capitalize"><?php echo e($article->judul_artikel); ?></h1>
            <div class="mt-10 flex flex-warp justify-center space-x-6">
                
                <?php if($article->file_revisi != NULL): ?>
                <div class="flex">
                    <a href="<?php echo e(asset('revisi_files/'.$article->file_revisi)); ?>" target="_blank"><button type="button" class="font-bold text-white w-[200px] text-center bg-oranges hover:bg-orange-700 py-2 rounded-lg capitalize">Download Revisi Artikel</button></a>
                </div>
                <?php endif; ?>
                <?php if($article->loa_file != NULL): ?>
                <div class="flex">
                    <a href="<?php echo e(asset('loa_files/'.$article->loa_file)); ?>" target="_blank"><button type="button" class="font-bold text-white w-[200px] text-center bg-greens hover:bg-green-700 py-2 rounded-lg capitalize">Download LOA</button></a>
                </div>
                <?php endif; ?>
                <div class="flex">
                    <a href="<?php echo e(asset('article_files/'.$article->nama_file)); ?>" target="_blank"><button type="button" class="font-bold text-white w-[200px] text-center bg-reds hover:bg-red-700 py-2 rounded-lg capitalize">Download Artikel</button></a>
                </div>
                
                    <?php echo ($article->status == 'Revisi (E)')?'<a href="revisi">':((($article->status == 'Proses')||($article->status == 'Verifikasi (E)'))?'<a href="revisi_vendor">':'');?>
                <div class="capitalize font-bold text-white bg-blue-500 px-20 py-2 rounded-[10px]"><?php echo e(($article->status == 'Verifikasi (E)')?'Proofreading':$article->status); ?></div>
                </a>
            </div>
        </div>
        <div class="bg-white px-14 py-11 h-96 rounded-[20px]  overflow-auto scrollbar-hide">
            <h1 class="text-3xl capitalize">komentar :</h1>
            <p class=" text-[22px]">
                <?php echo e(($article->komentar_vendor == "Belum ada komentar") ? $article->komentar_editor : $article->komentar_vendor); ?>

            </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipub_local\resources\views/user/details.blade.php ENDPATH**/ ?>