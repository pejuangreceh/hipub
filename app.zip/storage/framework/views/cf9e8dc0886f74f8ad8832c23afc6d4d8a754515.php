
<?php $__env->startSection('container'); ?>
<div class="h-auto w-full pt-10 px-10">
    <div class="flex flex-col space-y-8 mb-10">
        <div class="w-full py-2 px-10 flex justify-between rounded-xl bg-white">
            <div class="flex space-x-4">
                <div class=" w-10 h-10 p-2 my-auto rounded-full bg-pink-400 text-white">
                    <i class="bx bx-user bx-sm"></i>
                </div>
                <div class=" flex flex-col">                    
                    <h1 class="font-bold capitalize"><?php echo e($article[0]->name); ?></h1>
                    <h2 class=" text-sm"><?php echo e($article[0]->email); ?></h2>

                </div>
            </div>
            <div>
                <i class='bx bx-comment-dots bx-md mt-1'></i>
            </div>
        </div>
        <form action="<?php echo e(url('')); ?>/editor/<?php echo e($article[0]->id); ?>/save" method="POST" class="flex flex-col space-y-8" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="bg-white px-[77px] py-[30px] text-center rounded-xl">
                <h2 class=" text-xl capitalize">Judul Artikel</h2>
                <h1 class=" mt-8 font-bold text-xl capitalize"><?php echo e($article[0]->judul_artikel); ?></h1>
                <div class="mt-10 flex flex-warp justify-center space-x-6">
                    <div>
                        <a href="<?php echo e(asset('article_files/'.$article[0]->nama_file)); ?>" target="_blank"><button type="button" class="font-bold text-white w-[200px] text-center bg-reds hover:bg-red-700 py-2 rounded-lg capitalize">Download Artikel</button></a>
                    </div>
                    <div>
                        <a href="<?php echo e(asset('payment_files/'.$article[0]->file_bukti)); ?>" target="_blank"><button type="button" class="font-bold text-white w-[200px] text-center bg-blues hover:bg-blue-700 py-2 rounded-lg capitalize">Bukti Pembayaran</button></a>
                    </div>
                    <div class="flex">
                        
                        <select name="status" class="py-2 w-[200px] text-center rounded-lg capitalize bg-oranges hover:bg-orange-700 text-white font-semibold appearance-none cursor-pointer" required>
                            <option selected disabled class="capitalize">pilih status</option>
                            <option <?php echo e(($article[0]->status == 'Revisi (E)')?'selected':''); ?> class="capitalize" value="Revisi (E)">revisi</option>
                            <option <?php echo e(($article[0]->status == 'Verifikasi (E)')?'selected':''); ?> class="capitalize" value="Verifikasi (E)">Proofreading</option>

                        </select>
                    </div>     
                </div>
            </div>
            <div class="bg-white px-14 py-10 h-96 rounded-xl">
                <h1 class="text-xl capitalize">komentar :</h1>
                <p class="mt-2 h-[50px] overflow-auto scrollbar-hide">
                        <input type="text" value="<?php echo e($article[0]->komentar_editor); ?>" name="komentar_editor" id="" style="border-width: 2px;width: 100%;max-height:250px;" required>
                </p>
                <h1 class="text-xl capitalize">File Revisi</h1>
                <p class="mt-2 overflow-auto scrollbar-hide">
                        <input type="file" name="file_revisi" style="border-width: 2px;width: 100%;max-height:250px;">
                </p>
            </div>
            <div>
                <button class="float-right font-bold text-white w-[200px] text-center bg-primary hover:bg-primaryhover py-2 rounded-lg capitalize">Submit</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipub_local\resources\views/editor/details.blade.php ENDPATH**/ ?>