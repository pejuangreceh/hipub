
<?php $__env->startSection('container'); ?>

    <div class="h-screen w-full">
        
        <div>
            <a href="/add_article">
                Link Tambah Artikel
            </a>
        </div>
        <table>
            <tr>
                <th>ID Artikel</th>
                <th>Judul Artikel</th>
                <th>Status</th>
                <th colspan="3">Aksi</th>
            </tr>
            <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($a->id); ?></td>
                <td><?php echo e($a->judul_artikel); ?></td>
                <td><?php echo e($a->status); ?></td>
                <td><a href="show_article/<?php echo e($a->id); ?>">Show </a></td>
                <td><a href="edit_article/<?php echo e($a->id); ?>">Edit </a></td>
                <form action="hapus_article/<?php echo e($a->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <td><input type="submit" value="Hapus"></td>
                </form>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hipub\resources\views/article/index_article.blade.php ENDPATH**/ ?>